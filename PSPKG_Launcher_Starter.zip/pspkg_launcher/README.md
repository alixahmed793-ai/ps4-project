# PSPKG Launcher (starter project)

This is a **starter project**, not a prebuilt or tested PKG. It is intended to build a small PS4 homebrew app that requests the PS4 system browser to open `https://pspkg.com/ar/home`.

## Important limitations
- It does **not** embed the website inside the app. It launches the PS4 browser at PSPKG.
- The project has not been built or tested on a real PS4, and the OpenOrbis toolchain/API compatibility may require fixes.
- Do not install any resulting package unless the GitHub Actions run succeeds and you understand it is an experimental homebrew build.

## Cloud build from a phone
1. Sign in to GitHub and create a **new empty repository**.
2. Upload the files and folders from this project, keeping `.github/workflows/build.yml` in the exact path shown.
3. Open the repository's **Actions** tab and run `Build PSPKG Launcher PKG` (or push to `main`).
4. If the workflow succeeds, open that run and download the `PSPKG-Launcher-PKG` artifact. It will be a ZIP containing the `.pkg` output.

Official toolchain reference: https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain
Official cloud-build instructions: https://github.com/Cryptogenic/OpenOrbis-PS4-Toolchain-1/blob/master/DOCKER.md
