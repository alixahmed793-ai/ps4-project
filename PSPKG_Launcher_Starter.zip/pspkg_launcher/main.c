/* PSPKG Launcher - PS4 homebrew starter project.
 * It asks the PS4 system browser to open PSPKG. This is a launcher, not an embedded browser.
 * Build/runtime behavior has not been tested on a physical console.
 */
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>

/* These functions are provided by the PS4 kernel on supported homebrew setups. */
extern int sceKernelLoadStartModule(const char *moduleFileName, size_t args,
                                    const void *argp, uint32_t flags,
                                    void *pOpt, int *pRes);
extern int sceKernelDlsym(int moduleHandle, const char *symbol, void **addr);

typedef int (*LaunchWebBrowserFn)(const char *uri, void *param);

int main(int argc, char *argv[]) {
    (void)argc; (void)argv;
    int module = sceKernelLoadStartModule(
        "/system/common/lib/libSceSystemService.sprx", 0, NULL, 0, NULL, NULL);
    if (module < 0) {
        printf("PSPKG Launcher: failed to load SystemService (%d)\n", module);
        return 1;
    }

    void *symbol = NULL;
    int rc = sceKernelDlsym(module, "sceSystemServiceLaunchWebBrowser", &symbol);
    if (rc < 0 || symbol == NULL) {
        printf("PSPKG Launcher: browser launch function unavailable (%d)\n", rc);
        return 2;
    }

    LaunchWebBrowserFn launchBrowser = (LaunchWebBrowserFn)symbol;
    rc = launchBrowser("https://pspkg.com/ar/home", NULL);
    printf("PSPKG Launcher: browser request returned %d\n", rc);
    return (rc < 0) ? 3 : 0;
}
